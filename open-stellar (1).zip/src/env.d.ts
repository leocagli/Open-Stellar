/// <reference types="@cloudflare/workers-types" />

import type { Sandbox } from '@cloudflare/sandbox';
